<?php
session_start();
include('config.php');

if ($_SESSION['user_type'] != 'maintenance') {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];
    $sql = "UPDATE support_requests SET status = '$status' WHERE id = $request_id";
    if (mysqli_query($conn, $sql)) {
        header("Location: maintenance_dashboard.php");
        exit();
    } else {
        echo "خطأ في تحديث الحالة: " . mysqli_error($conn);
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    $request_id = $_POST['request_id'];
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $sender_type = 'maintenance';

    $sql = "INSERT INTO messages (request_id, sender_type, message) VALUES ('$request_id', '$sender_type', '$message')";
    echo mysqli_query($conn, $sql) ? "تم إرسال الرسالة بنجاح." : "خطأ في الإرسال: " . mysqli_error($conn);
}

$sql = "SELECT sr.id, e.name, sr.problem_type, sr.description, sr.status, sr.created_at
        FROM support_requests sr
        JOIN employees e ON sr.user_id = e.employee_id
        WHERE sr.status IN ('تم استلام الطلب', 'جاري المعالجة')
        ORDER BY sr.status, sr.created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم الفني</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>

<div id="welcomeModal" class="modal">
    <div class="modal-content">
        <span class="close-button">&times;</span>
        <h2>مرحبًا بك في لوحة تحكم الفني ✨</h2>
        <p>نتمنى لك تجربة مميزة وإدارة سهلة للمستخدمين </p>
    </div>
</div>

<h3>الطلبات الحالية</h3>
<table>
    <tr>
        <th>المستخدم</th>
        <th>نوع المشكلة</th>
        <th>الوصف</th>
        <th>الحالة</th>
        <th>إجراءات</th>
        <th>عرض الرسائل</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['problem_type']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td>
                <form action="maintenance_dashboard.php" method="POST">
                    <input type="hidden" name="request_id" value="<?php echo $row['id']; ?>">
                    <select name="status">
                        <option value="تم استلام الطلب" <?php if ($row['status'] == 'تم استلام الطلب') echo 'selected'; ?>>تم استلام الطلب</option>
                        <option value="جاري المعالجة" <?php if ($row['status'] == 'جاري المعالجة') echo 'selected'; ?>>جاري المعالجة</option>
                        <option value="تم حل المشكلة" <?php if ($row['status'] == 'تم حل المشكلة') echo 'selected'; ?>>تم حل المشكلة</option>
                    </select>
                    <button type="submit" name="update_status">تحديث</button>
                </form>
            </td>
            <td>
                <a href="maintenance_dashboard.php?request_id=<?php echo $row['id']; ?>">عرض الرسائل</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<?php if (isset($_GET['request_id'])): ?>
    <h3>الرسائل الخاصة بالطلب</h3>
    <?php
    $request_id = $_GET['request_id'];
    $messages_sql = "SELECT * FROM messages WHERE request_id = $request_id ORDER BY sent_at ASC";
    $messages_result = mysqli_query($conn, $messages_sql);
    while ($message_row = mysqli_fetch_assoc($messages_result)):
    ?>
        <p><strong><?php echo $message_row['sender_type'] == 'normal' ? 'المستخدم:' : 'الفني:'; ?></strong>
        <?php echo $message_row['message']; ?> <br>
        <small><?php echo $message_row['sent_at']; ?></small></p>
    <?php endwhile; ?>

    <form action="maintenance_dashboard.php" method="POST">
        <input type="hidden" name="request_id" value="<?php echo $request_id; ?>">
        <textarea name="message" required placeholder="اكتب ردك هنا..."></textarea><br><br>
        <button type="submit" name="send_message">إرسال رسالة</button>
    </form>
<?php endif; ?>

<br><a href="logout.php">تسجيل الخروج</a>

<script src="script.js"></script>
</body>
</html>

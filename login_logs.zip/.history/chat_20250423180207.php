<?php
session_start();
include('config.php');

// تأكد أن المستخدم مسجل دخول
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header('Location: login.php');
    exit();
}

$request_id = intval($_GET['id']);
$user_type = $_SESSION['user_type'];

// جلب الرسائل الخاصة بالطلب
$sql = "SELECT * FROM messages WHERE request_id = $request_id ORDER BY sent_at ASC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>الدردشة</title>
</head>
<body>
    <h2>محادثة الدعم - رقم الطلب: <?= $request_id ?></h2>

    <div style="border:1px solid #ccc; padding:10px; max-width:600px;">
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <p>
                <strong><?= $row['sender_type'] == 'normal' ? '👤 مستخدم' : '🔧 فني' ?>:</strong><br>
                <?= nl2br(htmlspecialchars($row['message'])) ?><br>
                <small><?= $row['sent_at'] ?></small>
            </p>
            <hr>
        <?php endwhile; ?>
    </div>

    <form action="send_message.php" method="POST" style="margin-top: 20px;">
        <input type="hidden" name="request_id" value="<?= $request_id ?>">
        <textarea name="message" rows="4" cols="50" required></textarea><br><br>
        <button type="submit">إرسال</button>
    </form>

    <br><a href="<?= $user_type == 'maintenance' ? 'maintenance_dashboard.php' : 'user_dashboard.php' ?>">رجوع</a>
</body>
</html>

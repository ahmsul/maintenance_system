<table>
  <tr>
    <th>رقم</th>
    <th>الجهاز</th>
    <th>الوصف</th>
    <th>القسم</th>
    <th>الحالة</th>
    <th>التاريخ</th>
    <th>تحديث الحالة</th>
  </tr>

  <?php while($row = mysqli_fetch_assoc($result)): ?>
  <tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['device'] ?></td>
    <td><?= $row['description'] ?></td>
    <td><?= $row['department'] ?></td>
    <td><?= $row['status'] ?></td>
    <td><?= $row['created_at'] ?></td>
    <td>
      <form action="update_status.php" method="post">
        <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <select name="status">
          <option value="جاري المعالجة" <?= $row['status'] == "جاري المعالجة" ? "selected" : "" ?>>جاري المعالجة</option>
          <option value="تمت المعالجة" <?= $row['status'] == "تمت المعالجة" ? "selected" : "" ?>>تمت المعالجة</option>
          <option value="قيد الانتظار" <?= $row['status'] == "قيد الانتظار" ? "selected" : "" ?>>قيد الانتظار</option>
          <option value="تم الإلغاء" <?= $row['status'] == "تم الإلغاء" ? "selected" : "" ?>>تم الإلغاء</option>
        </select>
        <button type="submit">تحديث</button>
      </form>
    </td>
  </tr>
  <?php endwhile; ?>
</table>

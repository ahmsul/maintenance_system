<?php
session_start(); // تأكد من أنك تبدأ الجلسة هنا

// تحقق من الجلسة
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header('Location: admin.php');  // إذا كان الدور هو "admin"
    exit();
} else {
    header('Location: user.php');   // إذا كان الدور شيء آخر أو لا يوجد
    exit();
}
?>

<?php
// admin.php
include 'auth.php';
if ($_SESSION['role']!=='admin') { header('Location: user.php'); exit; }

$con = new mysqli("localhost","root","","m_system");
$msg='';

// 1) إضافة مستخدم جديد
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['create_user'])) {
    $u = $_POST['username'];
    $p = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $r = 'user';
    if ($con->query("INSERT INTO users (username,password,role) VALUES ('$u','$p','$r')")) {
        $msg = "تم إنشاء المستخدم بنجاح.";
    } else {
        $msg = "خطأ: " . $con->error;
    }
}

// 2) معالجة تحديث حالة الطلب
if (isset($_POST['update_request'])) {
    $id     = $_POST['req_id'];
    $status = $_POST['status'];
    $con->query("UPDATE requests SET status='$status' WHERE id=$id");
    header('Location: admin.php');
    exit;
}

// جلب المستخدمين والطلبات
$users   = $con->query("SELECT id,username FROM users WHERE role='user'");
$requests= $con->query("SELECT r.*,u.username 
                        FROM requests r 
                        JOIN users u ON r.user_id=u.id 
                        ORDER BY r.created_at DESC");
?>
<!DOCTYPE html><html lang="ar"><head><meta charset="UTF-8"><title>الادمن</title>
<style>
  body{font-family:Arial;direction:rtl;padding:20px;background:#eef;}
  .box{background:#fff;padding:15px;margin-bottom:20px;
       border-radius:6px;box-shadow:0 0 5px rgba(0,0,0,0.1);}
  input,select,button{margin:5px 0;padding:8px;width:100%;}
  table{width:100%;border-collapse:collapse;margin-top:10px;}
  th,td{border:1px solid #ccc;padding:8px;text-align:center;}
</style>
</head><body>

<div class="box">
  <h3>إنشاء حساب مستخدم جديد</h3>
  <?php if($msg) echo "<p>$msg</p>"; ?>
  <form method="post">
    <input type="hidden" name="create_user" value="1">
    <input name="username" placeholder="اسم المستخدم" required>
    <input name="password" type="password" placeholder="كلمة المرور" required>
    <button>إنشاء</button>
  </form>
</div>

<div class="box">
  <h3>جميع طلبات الصيانة</h3>
  <table>
    <tr>
      <th>#</th><th>المستخدم</th><th>الجهاز</th>
      <th>الوصف</th><th>القسم</th><th>الحالة</th>
      <th>تاريخ الإنشاء</th><th>تحديث</th>
    </tr>
    <?php while($r=$requests->fetch_assoc()): ?>
    <tr>
      <td><?= $r['id'] ?></td>
      <td><?= $r['username'] ?></td>
      <td><?= $r['device'] ?></td>
      <td><?= $r['description'] ?></td>
      <td><?= $r['department'] ?></td>
      <td><?= $r['status'] ?></td>
      <td><?= $r['created_at'] ?></td>
      <td>
        <form method="post" style="margin:0;">
          <input type="hidden" name="update_request" value="1">
          <input type="hidden" name="req_id" value="<?= $r['id'] ?>">
          <select name="status">
            <?php 
              $st = ['جاري المعالجة','تمت المعالجة','قيد الانتظار','تم الإلغاء'];
              foreach($st as $s){
                $sel = $r['status']==$s?'selected':''; 
                echo "<option $sel>$s</option>";
              }
            ?>
          </select>
          <button>حفظ</button>
        </form>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>

<p><a href="logout.php">تسجيل خروج</a></p>
</body></html>
<?php $con->close(); ?>

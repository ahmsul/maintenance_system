<?php
// تأكد من أنك تبدأ الجلسة هنا
session_start();

// تحقق من البيانات المدخلة (البريد الإلكتروني وكلمة المرور)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM employees WHERE email = '$email' AND type = 'admin'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
        // التحقق من كلمة المرور
        if (password_verify($password, $user['password'])) {
            // إذا كانت البيانات صحيحة، قم ببدء الجلسة
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_type'] = $user['type'];
            $_SESSION['role'] = 'admin'; // تأكد من تعيين الدور بشكل صحيح

            // التوجيه إلى لوحة تحكم الأدمن
            header('Location: admin_dashboard.php');
            exit();
        } else {
            // في حال كانت كلمة المرور غير صحيحة
            $error_message = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
        }
    } else {
        // في حال كان البريد الإلكتروني غير موجود
        $error_message = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
    }
}
?>


<!-- HTML لتسجيل الدخول -->
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول</title>
</head>
<body>
    <h2>تسجيل الدخول كأدمن</h2>
    <?php if (isset($error_message)) { echo "<p style='color: red;'>$error_message</p>"; } ?>
    <form action="" method="POST">
        <label for="email">البريد الإلكتروني:</label><br>
        <input type="email" name="email" required><br><br>

        <label for="password">كلمة المرور:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">تسجيل الدخول</button>
    </form>
</body>
</html>

<?php
$con = mysqli_connect("localhost", "root", "", "m_system");
if (!$con) die("فشل الاتصال: " . mysqli_connect_error());

$id = $_POST['id'];
$status = $_POST['status'];

$sql = "UPDATE requests SET status = '$status' WHERE id = $id";

if (mysqli_query($con, $sql)) {
    header("Location: admin.php"); // يرجع لصفحة الإدارة
} else {
    echo "خطأ في التحديث: " . mysqli_error($con);
}

mysqli_close($con);
?>

<?php
$host = 'localhost';       // أو IP قاعدة البيانات
$username = 'root';        // اسم المستخدم
$password = '';            // كلمة المرور
$dbname = 'db_system';     // اسم قاعدة البيانات الصحيح

// إنشاء الاتصال
$conn = new mysqli($host, $username, $password, $dbname);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}
?>

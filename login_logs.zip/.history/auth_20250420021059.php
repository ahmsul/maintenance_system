<?php
session_start();
include 'db_system.php';

$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

$query = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) === 1) {
    $user = mysqli_fetch_assoc($result);

    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['user_type'] = $user['user_type'];
        $_SESSION['department'] = $user['department'];

        // توجيه حسب نوع المستخدم
        if ($user['user_type'] == 'admin') {
            header("Location: admin.php");
        } elseif ($user['user_type'] == 'employee') {
            header("Location: request_maintenance.php");
        } elseif ($user['user_type'] == 'maintenance') {
            header("Location: view_requests.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    }
}

header("Location: login.php?error=بيانات الدخول غير صحيحة");
exit();

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "m"; // تأكد من أنك تستخدم اسم القاعدة الصحيح

// إنشاء الاتصال
$conn = mysqli_connect($servername, $username, $password, $dbname);

// التحقق من الاتصال
if (!$conn) {
    die("فشل الاتصال بقاعدة البيانات: " . mysqli_connect_error());
}
?>

<?php
$con = mysqli_connect("localhost", "root", "", "m_system");
if (!$con) die("فشل الاتصال: " . mysqli_connect_error());

$result = mysqli_query($con, "SELECT * FROM requests ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>لوحة الطلبات</title>
  <style>
    body { font-family: Arial; direction: rtl; background: #eee; padding: 20px; }
    table { width: 100%; background: white; border-collapse: collapse; margin-top: 20px; }
    th, td { border: 1px solid #ccc; padding: 10px; text-align: center; }
    h2 { text-align: center; }
  </style>
</head>
<body>

<h2>جميع الطلبات</h2>

<table>
  <tr>
    <th>رقم</th>
    <th>الجهاز</th>
    <th>الوصف</th>
    <th>القسم</th>
    <th>الحالة</th>
    <th>التاريخ</th>
    <th>تحديث الحالة</th>
  </tr>

  <?php while($row = mysqli_fetch_assoc($result)): ?>
  <tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['device'] ?></td>
    <td><?= $row['description'] ?></td>
    <td><?= $row['department'] ?></td>
    <td><?= $row['status'] ?></td>
    <td><?= $row['created_at'] ?></td>
    <td>
      <form action="update_status.php" method="post">
        <input type="hidden" name="id" value="<?= $row['id'] ?>">
        <select name="status">
          <option value="جاري المعالجة" <?= $row['status'] == "جاري المعالجة" ? "selected" : "" ?>>جاري المعالجة</option>
          <option value="تمت المعالجة" <?= $row['status'] == "تمت المعالجة" ? "selected" : "" ?>>تمت المعالجة</option>
          <option value="قيد الانتظار" <?= $row['status'] == "قيد الانتظار" ? "selected" : "" ?>>قيد الانتظار</option>
          <option value="تم الإلغاء" <?= $row['status'] == "تم الإلغاء" ? "selected" : "" ?>>تم الإلغاء</option>
        </select>
        <button type="submit">تحديث</button>
      </form>
    </td>
  </tr>
  <?php endwhile; ?>
</table>


</body>
</html>

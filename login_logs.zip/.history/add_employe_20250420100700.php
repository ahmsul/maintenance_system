<?php
// اتصال بقاعدة البيانات
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $department = $_POST['department'];
    $type = $_POST['type'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);  // تشفير كلمة المرور

    // إدخال البيانات في قاعدة البيانات
    $sql = "INSERT INTO employees (name, email, department, type, password) VALUES ('$name', '$email', '$department', '$type', '$password')";
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<link rel="stylesheet" href="style2.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة موظف</title>
</head>
<body>
    <h2>إضافة موظف</h2>
    <form action="" method="POST">
        <label for="name">الاسم:</label><br>
        <input type="text" name="name" required><br><br>

        <label for="email">البريد الإلكتروني:</label><br>
        <input type="email" name="email" required><br><br>

        <label for="department">القسم:</label><br>
        <input type="text" name="department" required><br><br>

        <label for="type">النوع:</label><br>
        <select name="type" required>
            <option value="normal">موظف عادي</option>
            <option value="maintenance">موظف صيانة</option>
        </select><br><br>

        <label for="password">كلمة المرور:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">إضافة الموظف</button>
    </form> </form> <script src="script.js"></script>
</body> 
</html>

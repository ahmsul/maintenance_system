<?php
session_start(); // تأكد من بدء الجلسة هنا

// التحقق من الدور في الجلسة
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header('Location: admin.php');  // إذا كان الدور هو "admin"
    exit();
} else {
    header('Location: user.php');   // إذا كان الدور شيء آخر أو لا يوجد
    exit();
}
?>


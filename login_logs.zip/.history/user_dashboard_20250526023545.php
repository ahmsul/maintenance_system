<?php
session_start();
include('config.php');

if ($_SESSION['user_type'] != 'normal') {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$success_message = "";

// رفع طلب جديد
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_request'])) {
    $problem_type = mysqli_real_escape_string($conn, $_POST['problem_type']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "INSERT INTO support_requests (user_id, problem_type, description) 
            VALUES ('$user_id', '$problem_type', '$description')";
    if (mysqli_query($conn, $sql)) {
        $success_message = "تم رفع الطلب بنجاح.";
    } else {
        $success_message = "خطأ في رفع الطلب: " . mysqli_error($conn);
    }
}

// جلب الطلبات السابقة للمستخدم
$requests = mysqli_query($conn, "SELECT * FROM support_requests WHERE user_id = $user_id ORDER BY created_at DESC");

// إضافة الرسائل بين المستخدم والفني
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $sender_type = 'normal';  // نوع المرسل (مستخدم عادي)

    // إضافة الرسالة في قاعدة البيانات
    $sql = "INSERT INTO messages (request_id, sender_type, message) 
            VALUES ('$user_id', '$sender_type', '$message')";
    if (mysqli_query($conn, $sql)) {
        $success_message = "تم إرسال الرسالة بنجاح.";
    } else {
        $success_message = "خطأ في إرسال الرسالة: " . mysqli_error($conn);
    }
}
// إرسال الرسائل
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_message'])) {
    $request_id = $_POST['request_id'];
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $sender_type = 'maintenance';

    $sql = "INSERT INTO messages (request_id, sender_type, message) VALUES ('$request_id', '$sender_type', '$message')";
    if (mysqli_query($conn, $sql)) {
        echo "تم إرسال الرسالة بنجاح.";
    } else {
        echo "خطأ في إرسال الرسالة: " . mysqli_error($conn);
    }
}

// استرجاع الرسائل
$messages = mysqli_query($conn, "SELECT * FROM messages WHERE request_id = $user_id ORDER BY sent_at DESC");
?>

<!DOCTYPE html>
<html lang="ar">
<head>
<link rel="stylesheet" href="style2.css">
    <meta charset="UTF-8">
    <title>لوحة تحكم المستخدم العادي</title>
</head>
<body>

<div id="welcomeModal" class="modal">
    <div class="modal-content">
        <span class="close-button">&times;</span>
        <h2>مرحبًا بك في لوحة تحكم المستخدم العادي ✨</h2>
        <p>نتمنى لك تجربة مميزة وإدارة سهلة للمستخدمين!</p>
    </div>
</div>

<h3>رفع طلب دعم</h3>

<?php if (!empty($success_message)) echo "<p style='color:green;'>$success_message</p>"; ?>

<form action="user_dashboard.php" method="POST">
    <label>نوع المشكلة:</label><br>
    <input type="text" name="problem_type" required><br><br>

    <label>وصف المشكلة:</label><br>
    <textarea name="description" required></textarea><br><br>

    <button type="submit" name="submit_request">رفع الطلب</button>
</form>

<br><hr><br>

<h3>طلباتي السابقة</h3>
<table border="1">
    <tr>
        <th>نوع المشكلة</th>
        <th>الوصف</th>
        <th>الحالة</th>
        <th>التاريخ</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($requests)): ?>
        <tr>
            <td><?php echo $row['problem_type']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td><?php echo $row['created_at']; ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<br><hr><br>

<h3>الدردشة مع الفني</h3>

<form action="user_dashboard.php" method="POST">
    <textarea name="message" placeholder="اكتب رسالتك هنا" required></textarea><br>
    <button type="submit" name="send_message">إرسال الرسالة</button>
</form>

<h3>الرسائل السابقة</h3>
<div class="messages">
    <?php while ($row = mysqli_fetch_assoc($messages)) { ?>
        <p><strong><?php echo $row['sender_type'] == 'normal' ? 'المستخدم' : 'الفني'; ?>: </strong><?php echo $row['message']; ?> <small><?php echo $row['sent_at']; ?></small></p>
    <?php } ?>
</div>

<br>
<a href="logout.php">تسجيل الخروج</a>

<!-- إخفاء المودال تلقائي بعد 3 ثواني -->
<script>
    setTimeout(function() {
        var modal = document.getElementById("welcomeModal");
        if (modal) modal.style.display = "none";
    }, 3000);
</script>

</body>
</html>

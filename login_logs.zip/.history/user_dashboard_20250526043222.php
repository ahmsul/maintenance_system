<?php
session_start();
include('config.php');

if ($_SESSION['user_type'] != 'normal') {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// جلب اسم المستخدم
$user_sql = "SELECT name FROM employees WHERE employee_id = $user_id";
$user_result = mysqli_query($conn, $user_sql);
$user_name = "المستخدم";
if ($user_row = mysqli_fetch_assoc($user_result)) {
    $user_name = $user_row['name'];
}

// جلب جميع طلبات المستخدم
$request_ids = [];
$request_sql = "SELECT id FROM support_requests WHERE user_id = $user_id";
$request_result = mysqli_query($conn, $request_sql);
while ($row = mysqli_fetch_assoc($request_result)) {
    $request_ids[] = $row['id'];
}

$messages = [];
if (count($request_ids) > 0) {
    $ids_string = implode(',', $request_ids);
    $messages_sql = "SELECT * FROM messages WHERE request_id IN ($ids_string) ORDER BY sent_at ASC";
    $messages_result = mysqli_query($conn, $messages_sql);
    while ($msg = mysqli_fetch_assoc($messages_result)) {
        $messages[] = $msg;
    }
}

?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>الرسائل الخاصة بالمستخدم <?php echo htmlspecialchars($user_name); ?></title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>

<h2>الرسائل الخاصة بالمستخدم: <?php echo htmlspecialchars($user_name); ?></h2>

<?php if (count($messages) > 0): ?>
    <?php foreach ($messages as $message): ?>
        <p>
            <strong>
                <?php echo ($message['sender_type'] == 'normal') ? 'المستخدم:' : 'الفني:'; ?>
            </strong>
            <?php echo htmlspecialchars($message['message']); ?>
            <br><small><?php echo $message['sent_at']; ?></small>
        </p>
    <?php endforeach; ?>
<?php else: ?>
    <p>لا توجد رسائل حالياً.</p>
<?php endif; ?>

<!-- نموذج ارسال رسالة جديدة مع اختيار الطلب -->
<form action="send_message.php" method="POST">
    <label for="request_id">اختر الطلب للإرسال:</label>
    <select name="request_id" id="request_id" required>
        <?php foreach ($request_ids as $rid): ?>
            <option value="<?php echo $rid; ?>">طلب رقم <?php echo $rid; ?></option>
        <?php endforeach; ?>
    </select>
    <br><br>
    <textarea name="message" required placeholder="اكتب ردك هنا..."></textarea><br><br>
    <button type="submit" name="send_message">إرسال رسالة</button>
</form>

<br><a href="logout.php">تسجيل الخروج</a>

</body>
</html>

<?php
// dashboard.php
include 'auth.php';
if ($_SESSION['role']==='admin') {
    header('Location: admin.php');  exit;
} else {
    header('Location: user.php');   exit;
}

// التحقق من البيانات عند الضغط على زر "تسجيل الدخول"
document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form');
    const submitButton = form.querySelector('input[type="submit"]');

    submitButton.addEventListener('click', function (e) {
        e.preventDefault(); // منع إعادة تحميل الصفحة

        // الحصول على القيم المدخلة
        const email = form.querySelector('input[name="email"]').value;
        const password = form.querySelector('input[name="password"]').value;

        // هنا يمكنك إضافة التحقق من البريد وكلمة المرور
        if (email === 'admin@example.com' && password === '1234') {
            alert("مرحبًا، تم تسجيل الدخول بنجاح.");
            window.location.href = "admin_dashboard.php";  // توجيه المستخدم إلى لوحة التحكم
        } else {
            alert("البريد الإلكتروني أو كلمة المرور غير صحيحة.");
        }
    });
});

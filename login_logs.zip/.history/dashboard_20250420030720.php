<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();  // تأكد من بدء الجلسة

// تحقق إذا كان المستخدم قد سجل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');  // إعادة التوجيه إلى صفحة تسجيل الدخول إذا لم يكن هناك جلسة
    exit();
}

echo "مرحبًا، " . $_SESSION['user_name'];  // عرض اسم المستخدم
?>

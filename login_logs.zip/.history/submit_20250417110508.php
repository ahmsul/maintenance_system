<?php
$con = mysqli_connect("localhost", "root", "", "m_system");

if (!$con) {
    die("فشل الاتصال: " . mysqli_connect_error());
}

$device = $_POST['device'];
$description = $_POST['description'];
$department = $_POST['department'];

$sql = "INSERT INTO requests (device, description, department) 
        VALUES ('$device', '$description', '$department')";

if (mysqli_query($con, $sql)) {
    echo "تم إرسال الطلب بنجاح!";
} else {
    echo "فشل في الإرسال: " . mysqli_error($con);
}

mysqli_close($con);
?>

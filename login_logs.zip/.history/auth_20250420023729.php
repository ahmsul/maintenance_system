<?php
// تأكد من أن الاتصال بقاعدة البيانات موجود هنا
include('شعفا'); // تأكد من أن ملف الاتصال بقاعدة البيانات موجود في هذا الملف

// إذا كان الاتصال مغلقًا (لسبب ما)، قم بإعادة فتحه
if (!$conn->ping()) {
    $conn = new mysqli($host, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
    }
}

// التحقق من تسجيل الدخول
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = mysqli_real_escape_string($conn, $_POST['email']); // استخدم الاتصال المفتوح هنا
    $password = mysqli_real_escape_string($conn, $_POST['password']); // استخدم الاتصال المفتوح هنا

    // استعلام التحقق من البريد الإلكتروني وكلمة المرور
    $sql = "SELECT * FROM employees WHERE email = '$email' AND type = 'normal'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // التحقق من كلمة المرور
        if (password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_type'] = $user['type'];
            header('Location: admin_dashboard.php');  // التوجيه إلى لوحة تحكم الأدمن
            exit();
        } else {
            $error_message = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
        }
    } else {
        $error_message = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
    }
}
?>

<!-- HTML لتسجيل الدخول -->
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول</title>
</head>
<body>
    <h2>تسجيل الدخول كأدمن</h2>
    <?php if (isset($error_message)) { echo "<p style='color: red;'>$error_message</p>"; } ?>
    <form action="" method="POST">
        <label for="email">البريد الإلكتروني:</label><br>
        <input type="email" name="email" required><br><br>

        <label for="password">كلمة المرور:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">تسجيل الدخول</button>
    </form>
</body>
</html>

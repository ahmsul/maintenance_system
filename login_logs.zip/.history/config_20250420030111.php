<?php
error_reporting(E_ALL);  // تفعيل عرض جميع الأخطاء
ini_set('display_errors', 1);  // عرض الأخطاء في المتصفح

// الاتصال بقاعدة البيانات
$conn = mysqli_connect('localhost', 'root', '', 'your_database');

if (!$conn) {
    die('فشل الاتصال بقاعدة البيانات: ' . mysqli_connect_error());
}
?>

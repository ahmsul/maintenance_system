<?php
$host = 'localhost';
$username = 'root';  // اسم المستخدم
$password = '';  // كلمة المرور
$dbname = 'your_database_name';  // اسم قاعدة البيانات

// إنشاء الاتصال
$conn = mysqli_connect($host, $username, $password, $dbname);

// التحقق من الاتصال
if (!$conn) {
    die("فشل الاتصال بقاعدة البيانات: " . mysqli_connect_error());
}
?>

<?php
// setup.php

$host = "localhost";  
$user = "root";  
$pass = "";

// 1) اتصل بالسيرفر
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("فشل الاتصال بالسيرفر: " . $conn->connect_error);
}

// 2) أنشئ قاعدة البيانات
$conn->query("CREATE DATABASE IF NOT EXISTS m_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db("m_system");

// 3) إنشاء جدول الموظفين (employees)
$conn->query("
CREATE TABLE IF NOT EXISTS employees (
    emid INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    department VARCHAR(100) NOT NULL,
    type ENUM('normal', 'maintenance', 'admin') NOT NULL,
    password VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// 4) إنشاء جدول طلبات الدعم (support_requests)
$conn->query("
CREATE TABLE IF NOT EXISTS support_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    problem_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('تم استلام الطلب', 'تم حل المشكلة', 'جاري المعالجة') DEFAULT 'تم استلام الطلب',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES employees(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");



// 6) إنشاء جدول طلبات الصيانة (maintenance_requests)

$conn->query("CREATE TABLE login_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255),
    success BOOLEAN,
    ip_address VARCHAR(100),
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP
);");
$conn->query("CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    sender_type ENUM('normal', 'maintenance') NOT NULL,
    message TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES support_requests(id) ON DELETE CASCADE
);");

// 8) إضافة حساب الأدمن إذا لم يكن موجودًا
$pwd = password_hash('1234', PASSWORD_DEFAULT);
$sql = "
INSERT IGNORE INTO employees (name, email, department, type, password) 
VALUES ('Admin', 'admin@example.com', 'Admin', 'admin', '$pwd')
";

// تنفيذ استعلام إضافة الأدمن
if (mysqli_query($conn, $sql)) {
    echo "تم إضافة حساب الأدمن بنجاح إذا لم يكن موجودًا.";
} else {
    echo "حدث خطأ أثناء إضافة حساب الأدمن: " . mysqli_error($conn);
}

echo "تم إنشاء القاعدة والجداول وحساب الادمن بنجاح.";
$conn->close();
?>

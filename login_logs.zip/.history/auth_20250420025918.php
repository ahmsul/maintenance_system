<?php

session_start(); // بداية الجلسة

// تضمين ملف الاتصال بقاعدة البيانات
include('config.php'); // تأكد من أن هذا الملف يحتوي على الاتصال بقاعدة البيانات

// تحقق من البيانات المدخلة (البريد الإلكتروني وكلمة المرور)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // تأكد من أن الاتصال بقاعدة البيانات موجود
    if (!$conn) {
        die("فشل الاتصال بقاعدة البيانات: " . mysqli_connect_error());
    }

    // الهروب من الأحرف الخاصة (SQL Injection Protection)
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // استعلام للتحقق من المستخدم
    $sql = "SELECT * FROM employees WHERE email = '$email' AND type = 'admin'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // التحقق من كلمة المرور
        if (password_verify($password, $user['password'])) {
            // إذا كانت البيانات صحيحة، قم ببدء الجلسة
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_type'] = $user['type'];
            $_SESSION['role'] = 'admin'; // تعيين الدور للأدمن

            // التوجيه إلى لوحة تحكم الأدمن
            header('Location: admin_dashboard.php');
            exit();
        } else {
            // إذا كانت كلمة المرور غير صحيحة
            $error_message = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
        }
    } else {
        // إذا كان البريد الإلكتروني غير موجود في قاعدة البيانات
        $error_message = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>تسجيل الدخول</title>
</head>
<body>
    <h2>تسجيل الدخول</h2>

    <?php if (isset($error_message)): ?>
        <p style="color:red;"><?php echo htmlspecialchars($error_message); ?></p>
    <?php endif; ?>

    <form action="auth.php" method="POST">
        <label>البريد الإلكتروني:</label><br>
        <input type="email" name="email" required><br><br>

        <label>كلمة المرور:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">دخول</button>
    </form>
</body>
</html>

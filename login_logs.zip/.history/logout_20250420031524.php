<?php
session_start();  // بدء الجلسة

// تدمير الجلسة لتسجيل الخروج
session_unset();
session_destroy();

header('Location: login.php');  // إعادة التوجيه إلى صفحة تسجيل الدخول
exit();
?>

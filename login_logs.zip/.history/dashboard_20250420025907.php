<?php
error_reporting(E_ALL);  // تفعيل عرض جميع الأخطاء
ini_set('display_errors', 1);  // عرض الأخطاء مباشرة في المتصفح
session_start(); // تأكد من أنك تبدأ الجلسة هنا

// تحقق من الجلسة
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header('Location: admin.php');  // إذا كان الدور هو "admin"
    exit();
} else {
    header('Location: user.php');   // إذا كان الدور شيء آخر أو لا يوجد
    exit();
}
?>

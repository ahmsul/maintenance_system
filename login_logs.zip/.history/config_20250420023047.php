<?php
$host = 'localhost';       // أو IP قاعدة البيانات
$username = 'root';        // اسم المستخدم
$password = '';            // كلمة المرور
$dbname = 'your_database'; // اسم قاعدة البيانات

// إنشاء الاتصال
$conn = new mysqli($host, $username, $password, $dbname);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال بقاعدة البيانات: " . $conn->connect_error);
}
?>

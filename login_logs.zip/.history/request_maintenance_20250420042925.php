<?php
session_start();
include 'm_system.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'employee') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_department = $_SESSION['department'] ?? '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $query = "INSERT INTO maintenance_requests (employee_id, department, description)
              VALUES ('$user_id', '$user_department', '$description')";
    
    if (mysqli_query($conn, $query)) {
        $success = "تم إرسال طلب الصيانة بنجاح.";
    } else {
        $error = "حدث خطأ أثناء الإرسال.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>طلب صيانة</title>
</head>
<body>
    <h2>طلب صيانة</h2>
    
    <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>

    <form method="POST">
        <label>وصف المشكلة:</label><br>
        <textarea name="description" rows="5" cols="40" required></textarea><br><br>

        <button type="submit">إرسال الطلب</button>
    </form> </form> <script src="script.js"></script>
</body>
</html>

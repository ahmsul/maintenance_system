document.addEventListener("DOMContentLoaded", function() {
    // إضافة تأثير لطيف على النموذج عند التفاعل
    const form = document.querySelector("form");
    form.addEventListener("submit", function(event) {
      event.preventDefault(); // منع إرسال النموذج
      alert("تم تقديم البيانات بنجاح!"); // عرض تنبيه عند تقديم النموذج
    });
  
    // تأثير مخصص عند ترك الحقل فارغًا
    const emailField = document.querySelector("input[name='email']");
    const passwordField = document.querySelector("input[name='password']");
  
    emailField.addEventListener("blur", function() {
      if (!emailField.value) {
        emailField.style.borderColor = "red";
      } else {
        emailField.style.borderColor = "#ddd";
      }
    });
  
    passwordField.addEventListener("blur", function() {
      if (!passwordField.value) {
        passwordField.style.borderColor = "red";
      } else {
        passwordField.style.borderColor = "#ddd";
      }
    });
  });
  
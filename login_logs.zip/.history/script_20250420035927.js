// إضافة بعض الوظائف البسيطة مثل التحقق من الحقول
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        const email = document.querySelector('input[name="email"]');
        const password = document.querySelector('input[name="password"]');

        if (!email.value || !password.value) {
            event.preventDefault(); // منع إرسال النموذج
            alert("يرجى ملء جميع الحقول!");
        }
    });
});

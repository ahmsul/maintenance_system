// عند تحميل الصفحة
document.addEventListener("DOMContentLoaded", function () {
    // ترحيب عند الدخول
    console.log("أهلاً بك في لوحة التحكم!");
  
    // تأثير عند تمرير الماوس على زر الدخول
    const loginBtn = document.querySelector("#sbn");
    if (loginBtn) {
      loginBtn.addEventListener("mousedown", function () {
        loginBtn.style.transform = "scale(0.95)";
      });
      loginBtn.addEventListener("mouseup", function () {
        loginBtn.style.transform = "scale(1)";
      });
    }
  
    // تغيير لون الحقل عند الكتابة
    const inputs = document.querySelectorAll("input[type='text'], input[type='email'], input[type='password']");
    inputs.forEach(function (input) {
      input.addEventListener("focus", function () {
        input.style.borderBottom = "2px solid #2980b9";
      });
      input.addEventListener("blur", function () {
        input.style.borderBottom = "2px solid darkgray";
      });
    });
  
    // منع الإرسال الفارغ وإظهار تنبيه
    const form = document.querySelector("form");
    if (form) {
      form.addEventListener("submit", function (e) {
        let empty = false;
        inputs.forEach(function (input) {
          if (input.value.trim() === "") {
            empty = true;
          }
        });
  
        if (empty) {
          e.preventDefault();
          alert("يرجى تعبئة جميع الحقول قبل الإرسال.");
        }
      });
    }
  });
  
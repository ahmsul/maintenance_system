<?php
session_start();
include 'm_system.php';

// التحقق من تسجيل الدخول وأنه موظف صيانة
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'maintenance') {
    header("Location: login.php");
    exit();
}

$department = $_SESSION['department'];
// تحديث حالة الطلب
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id'], $_POST['new_status'])) {
    $request_id = (int)$_POST['request_id'];
    $new_status = mysqli_real_escape_string($conn, $_POST['new_status']);

    $update = "UPDATE maintenance_requests SET status = '$new_status' WHERE id = $request_id";
    mysqli_query($conn, $update);
}

// جلب الطلبات المرتبطة بنفس القسم
$query = "SELECT r.*, u.name AS employee_name 
          FROM maintenance_requests r
          JOIN users u ON r.employee_id = u.id
          WHERE r.department = '$department'
          ORDER BY r.created_at DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>طلبات الصيانة</title>
</head>
<body>
    <h2>طلبات الصيانة - قسم <?php echo htmlspecialchars($department); ?></h2>

    <table border="1" cellpadding="5" cellspacing="0">
        <thead>
            <tr>
                <th>الموظف</th>
                <th>الوصف</th>
                <th>الحالة</th>
                <th>تاريخ الإرسال</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['employee_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <title>طلب صيانة</title>
  <style>
    body { font-family: Arial; direction: rtl; background: #f5f5f5; padding: 20px; }
    .form-container { background: white; padding: 20px; border-radius: 10px; width: 400px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
    input, textarea, select { width: 100%; margin-bottom: 15px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }
    button { background-color: #007BFF; color: white; padding: 10px; border: none; border-radius: 5px; cursor: pointer; }
    button:hover { background-color: #0056b3; }
  </style>
</head>
<body>

<div class="form-container">
  <h2>طلب صيانة جديد</h2>
  <form action="submit.php" method="post">
    <label>اسم الجهاز:</label>
    <input type="text" name="device" required>

    <label>الوصف / المشكلة:</label>
    <textarea name="description" rows="4" required></textarea>

    <label>القسم:</label>
    <select name="department" required>
      <option value="">اختر القسم</option>
      <option value="الإدارة">الإدارة</option>
      <option value="المحاسبة">المحاسبة</option>
      <option value="الدعم الفني">الدعم الفني</option>
    </select>

    <button type="submit">إرسال الطلب</button>
  </form>
</div>

</body>
</html>

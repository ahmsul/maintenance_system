<?php
// user.php
include 'auth.php';
if ($_SESSION['role']!=='user') { header('Location: admin.php'); exit; }

$con = new mysqli("localhost","root","","m_system");
$uid = $_SESSION['user_id'];
$msg='';

// إضافة طلب جديد
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['add_req'])) {
    $d = $_POST['device'];
    $desc = $_POST['description'];
    $dep  = $_POST['department'];
    $con->query("
      INSERT INTO requests (user_id,device,description,department)
      VALUES ($uid,'$d','$desc','$dep')
    ");
    $msg = "تم إضافة الطلب.";
}

// تحديث حالة طلبه
if (isset($_POST['upd_req'])) {
    $id = $_POST['req_id'];
    $st = $_POST['status'];
    // تأكد أنه يملك الطلب
    $con->query("
      UPDATE requests 
      SET status='$st' 
      WHERE id=$id AND user_id=$uid
    ");
    header('Location: user.php');
    exit;
}

// جلب طلباته
$reqs = $con->query("
  SELECT * FROM requests 
  WHERE user_id=$uid 
  ORDER BY created_at DESC
");
?>
<!DOCTYPE html><html lang="ar"><head><meta charset="UTF-8"><title>مستخدم</title>
<style>
  body{font-family:Arial;direction:rtl;padding:20px;background:#f9f9f9;}
  .box{background:#fff;padding:15px;margin-bottom:20px;
       border-radius:6px;box-shadow:0 0 5px rgba(0,0,0,0.1);}
  input,select,button,textarea{margin:5px 0;padding:8px;width:100%;}
  table{width:100%;border-collapse:collapse;margin-top:10px;}
  th,td{border:1px solid #ccc;padding:8px;text-align:center;}
</style>
</head><body>

<div class="box">
  <h3>أضف طلب صيانة</h3>
  <?php if($msg) echo "<p>$msg</p>"; ?>
  <form method="post">
    <input type="hidden" name="add_req" value="1">
    <input name="device" placeholder="اسم الجهاز" required>
    <textarea name="description" rows="2" placeholder="الوصف" required></textarea>
    <select name="department" required>
      <option value="">-- اختر القسم --</option>
      <option>الإدارة</option>
      <option>المحاسبة</option>
      <option>الدعم الفني</option>
    </select>
    <button>إرسال</button>
  </form>
</div>

<div class="box">
  <h3>طلباتي</h3>
  <table>
    <tr>
      <th>#</th><th>الجهاز</th><th>الوصف</th>
      <th>القسم</th><th>الحالة</th><th>تاريخ الإنشاء</th><th>تحديث</th>
    </tr>
    <?php while($r=$reqs->fetch_assoc()): ?>
    <tr>
      <td><?= $r['id'] ?></td>
      <td><?= $r['device'] ?></td>
      <td><?= $r['description'] ?></td>
      <td><?= $r['department'] ?></td>
      <td><?= $r['status'] ?></td>
      <td><?= $r['created_at'] ?></td>
      <td>
        <form method="post" style="margin:0;">
          <input type="hidden" name="upd_req" value="1">
          <input type="hidden" name="req_id" value="<?= $r['id'] ?>">
          <select name="status">
            <?php 
              foreach(['جاري المعالجة','تمت المعالجة','قيد الانتظار','تم الإلغاء'] as $s){
                $sel = $r['status']==$s?'selected':''; 
                echo "<option $sel>$s</option>";
              }
            ?>
          </select>
          <button>حفظ</button>
        </form>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>

<p><a href="logout.php">تسجيل خروج</a></p>
</body></html>
<?php $con->close(); ?>
